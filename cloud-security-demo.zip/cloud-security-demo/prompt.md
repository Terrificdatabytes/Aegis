# Cloud Security Demo — Master Project Prompt

> **Purpose of this file:** Paste this whole file (or attach it) at the start of every new Claude session for this project. It contains the full context, architecture, constraints, and session plan so you don't have to re-explain anything. Update the **Progress Log** at the bottom after each session and re-attach it next time.

---

## 1. Project Summary

A live, ~30-minute demo that simulates a distributed cloud environment and shows three classes of security threats being **detected and prevented** in real time, visualized on a central dashboard.

**Infrastructure (demo-only, not production):**
- **5 "VM" nodes** = 5 Google Colab notebooks, each running a lightweight Python agent, used for the duration of the live demo only (not long-running — Colab free tier is not meant for persistent hosting).
- **Master/orchestrator server** = Python Flask app with an enterprise-grade Tailwind CSS dashboard, deployed on Render.com free tier.
- **Connectivity** = each Colab node exposes its local agent via **Cloudflare Tunnel** (`cloudflared`), giving it a reachable public URL that the master server talks to. (Alternatives if needed: Tailscale for a private mesh, ngrok for quick/simple tunnels with rotating URLs, localtunnel as a lightweight fallback.)
- In a real-world deployment this would be real VMs/cloud instances instead of Colab — Colab is explicitly a stand-in for the live demo to keep cost at zero.

**Three demo scenarios (all staged/scripted against synthetic data — see Constraints):**
1. **Cloud data breach** — scripted anomalous access against a synthetic dummy dataset, detected via access-pattern/volume anomaly detection, blocked and logged.
2. **Identity attack** — scripted credential-stuffing / token-replay attempt against a sandboxed auth endpoint, caught via rate-limiting + anomaly scoring, step-up response triggered.
3. **Virtualization threat** — scripted lateral-movement attempt from one node toward another node's internal port, blocked by tunnel/network-segmentation rules.

Each scenario fires a sequence of events to the master server, which displays them live on the dashboard as: **Attack Detected → Analysis → Prevented**, with timestamps, source node, severity, and the specific control that stopped it.

---

## 2. Hard Constraints (apply to every session, non-negotiable)

- All three "attacks" are **scripted/staged demonstrations against synthetic, self-owned data and sandboxed endpoints** — never real exploit code, real credential harvesting, real privilege escalation, or anything run against infrastructure that isn't yours and isn't set up specifically to receive it.
- The "attacker" scripts simulate the *pattern* of an attack (e.g., rapid sequential requests, replayed tokens, a node pinging another node's internal port) to trigger the detection logic — they don't need to be, and should not be, functional offensive tooling.
- The emphasis throughout is on the **detection and prevention logic being real and demonstrable**, while the "attack" side is theatrical/scripted for presentation purposes.
- Keep secrets (API keys, tunnel tokens) out of any committed files — use environment variables / `.env` (gitignored).

---

## 3. Target Repo Structure

```
cloud-security-demo/
├── master-server/           # Flask + Tailwind dashboard, deployed to Render
│   ├── app.py
│   ├── templates/
│   ├── static/
│   ├── events/               # event schema, in-memory or lightweight DB store
│   └── requirements.txt
├── node-agent/               # Single script run inside each Colab notebook
│   ├── agent.py
│   └── requirements.txt
├── scenarios/
│   ├── data_breach.py
│   ├── identity_attack.py
│   └── virtualization_threat.py
├── SETUP.md                  # Cloudflare Tunnel + Colab + Render setup steps
├── PROGRESS.md                # You update this after each session
└── prompt.md                  # This file
```

---

## 4. Shared Event Contract

Every node agent reports events to the master server in this shape (finalize/adjust in Session 1, then keep it stable):

```json
{
  "node_id": "node-1",
  "event_type": "data_breach | identity_attack | virtualization_threat | heartbeat",
  "stage": "detected | analyzing | prevented",
  "severity": "low | medium | high | critical",
  "timestamp": "ISO8601",
  "detail": "human-readable description of what happened",
  "control_applied": "name of the defensive mechanism that acted"
}
```

---

## 5. Session Plan

Work through these in order, one Claude session each. At the end of each session, ask Claude to **write all final code to files** and hand them to you, and update `PROGRESS.md` yourself before closing the session.

### Session 1 — Architecture & Scaffolding
- Lock in the repo structure and the event contract above (adjust as needed).
- Write `SETUP.md`: step-by-step Cloudflare Tunnel setup for a Colab-hosted agent, plus Render deployment steps for the master server.
- Create the empty/skeleton files per the repo structure.
- **Deliverable:** repo skeleton + SETUP.md.

### Session 2 — Master Server (Flask + Dashboard Shell)
- Flask backend: endpoint(s) to receive node events (REST and/or WebSocket/SSE for live push).
- Tailwind dashboard shell: node status grid (5 nodes, online/offline), live event feed panel, severity color-coding.
- Deploy to Render; confirm reachability from the public internet.
- **Deliverable:** working dashboard that displays a manually-POSTed test event correctly.

### Session 3 — Node Agent (shared code for all 5 nodes)
- Single parameterized Flask/FastAPI script to run in each Colab notebook.
- On startup: starts Cloudflare Tunnel, registers its public URL + node name with the master server, begins heartbeat.
- Generic `emit_event()` helper the scenario scripts will call.
- **Deliverable:** one script, copy-pasted into all 5 notebooks with a different `NODE_NAME` each.

### Session 4 — Scenario 1: Simulated Data Breach
- Synthetic dummy dataset + endpoint on one node.
- Scripted "attacker" sequence (unusual access pattern/volume) + real detection logic (anomaly/volume-based) + prevention action (block + alert), wired to emit events per the contract.
- **Deliverable:** first scenario working end-to-end, visible on dashboard.

### Session 5 — Scenario 2 & 3: Identity Attack + Virtualization Threat
- Identity attack: scripted credential-stuffing/token-replay against a sandboxed auth endpoint; caught via rate-limiting + anomaly scoring; step-up/lockout response.
- Virtualization threat: scripted lateral-movement attempt between two nodes; blocked via tunnel/network-segmentation rule; logged.
- **Deliverable:** both scenarios wired into the same dashboard alongside Scenario 1.

### Session 6 — Polish, Rehearsal & Demo Script
- Visual polish pass on the Tailwind dashboard (animations, transitions, "enterprise" feel).
- Time the full run-through to fit the 30-minute Colab window, with buffer.
- Write a literal run-of-show script: what you click/trigger, in what order, what the audience should be looking at, and fallback talking points if a tunnel drops mid-demo.
- **Deliverable:** final demo-ready build + run-of-show script.

---

## 6. Skills / Technical Knowledge Needed Per Session

Use this as a checklist of what each session will draw on — mention these explicitly if you want Claude to focus there.

| Area | Where it's used |
|---|---|
| Flask (routing, REST, WebSocket/SSE via `flask-sock` or similar) | Sessions 2, 3 |
| Tailwind CSS (utility classes, responsive grid, dark/enterprise theming) | Sessions 2, 6 |
| Cloudflare Tunnel (`cloudflared` install/run in a notebook environment, quick tunnels vs named tunnels) | Sessions 1, 3 |
| Render.com deployment (free web service, env vars, start command) | Sessions 1, 2 |
| Google Colab shell execution (`!` commands, background processes with `subprocess`/`nohup`, keeping a Flask dev server alive during the session) | Sessions 3, 4, 5 |
| Basic anomaly/rate-based detection logic (sliding window counters, simple thresholding) — no ML needed, just clear demonstrable logic | Sessions 4, 5 |
| Event-driven frontend updates (SSE/WebSocket client JS, or polling fallback) | Session 2, 6 |
| Secrets handling (`.env`, Render environment variables, not committing tunnel tokens) | All sessions |

---

## 7. Progress Log

> Update this section yourself at the end of each session before closing it. Re-paste this whole file (with the log updated) at the start of the next session.

- [ ] Session 1 — Architecture & Scaffolding — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance
- [ ] Session 2 — Master Server — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance
- [ ] Session 3 — Node Agent — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance
- [ ] Session 4 — Scenario 1 (Data Breach) — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance
- [ ] Session 5 — Scenario 2 & 3 (Identity + Virtualization) — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance
- [ ] Session 6 — Polish & Demo Script — **status:** implemented; see PROGRESS.md for validation and remaining cloud acceptance

**Notes / decisions carried forward:**
(add anything you decide mid-session that later sessions need to know, e.g. "used SSE not WebSocket", "Render URL is https://...")


## Implementation handoff — 2026-10-10
All six implementation phases delivered. 33 Python tests and local five-agent browser workflow passed. Cloud deployment/Colab/Cloudflare acceptance and timed cloud rehearsal are still pending. See PROGRESS.md, SETUP.md, ARCHITECTURE.md and RUN_OF_SHOW.md. Polling used instead of SSE; virtualization demonstrates a real application-level peer rejection, not an OS/hypervisor firewall.
