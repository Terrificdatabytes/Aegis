module.exports={content:['./master-server/templates/*.html','./master-server/static/*.js'],theme:{extend:{}},plugins:[]};
