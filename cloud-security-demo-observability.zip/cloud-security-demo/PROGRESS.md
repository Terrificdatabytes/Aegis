# Progress — 2026-10-10

Implementation of all six planned phases is present. Local verification is complete; cloud deployment and on-provider acceptance remain operator tasks.

| Phase | Status |
|---|---|
| 1 — Architecture/scaffolding | Complete: repo, v1 contract, architecture and setup docs |
| 2 — Master/dashboard | Implemented and locally tested; Render deployment pending |
| 3 — Shared agent | Implemented, five local processes verified; actual Colab/quick-tunnel acceptance pending |
| 4 — Data breach | Verified end-to-end locally, denied rows and sliding window tested |
| 5 — Identity/virtualization | Verified locally, including actual cross-process peer request and signed destination evidence |
| 6 — Polish/rehearsal | Responsive dashboard, CLI, notebook, run-of-show complete; cloud 30-minute dress rehearsal pending |

## Validation

- `python -m pytest -q tests`: **33 passed**.
- Playwright: operator login, five online agents, full sequence, 12 events / 4 incidents, independent peer evidence, severity/stage filters, navigation, JSON export and 390px mobile overflow checks passed. No JavaScript page errors.
- Python compilation and Tailwind CSS build passed.
- Full network rehearsal uses an actual Flask master and five agent processes, not prepopulated UI data.
- No deployment was performed to Render, Colab or Cloudflare. No claim of public cloud reachability or provider SLA is made.

## Decisions

- One-second polling instead of SSE: simple free-service/tunnel-friendly behavior; compiled Tailwind served locally, no runtime CDN dependency.
- SQLite bounded to 5,000 events, latest 300 in UI/export; ephemeral on Render free hosting. One worker, threaded requests.
- Per-node HMAC keys, replay nonce cache, login/CSRF controls. Root credentials stripped from local child-agent environments.
- Virtualization is explicitly application authentication/segmentation. One fixed peer harness request, 401 rejection, independently signed target event; failures never count as prevention. No hypervisor/OS firewall claim.
- Step-up response is an enforcement flag, not implemented MFA.
- Retry-deduplicated telemetry; reset suppresses late automated run events; restart marks in-flight runs failed/unknown.
- Real provider acceptance checklist and failure talking points are in SETUP.md and RUN_OF_SHOW.md.

## UI redesign — 2026-10-10

- Replaced hand-authored dashboard.css with Tailwind utilities; build now produces static/output.css.
- IBM Plex Sans/Mono self-hosted with OFL license; colors, four-size type scale, and layout tokens defined in tailwind.config.js.
- Flat navigation, chrome-free statistics, five compact node rows and exactly one contrasting surface for the signed event log.
- Added run IDs to event presentation. Kept polling, API, CSRF, triggers, filtering, reset and export behavior unchanged. No Python/backend changes.
- Screenshot review fixed excess node-row height and restricted severity color to the left border only.
- 33 Python tests pass. Existing Playwright workflow passes. New tests/redesign.cjs verifies fonts, four font sizes, exactly one panel background, no uppercase transforms, no middle-dot joins, no shadows, severity-side borders, desktop/mobile fit and no failed resource requests or JS errors.
- Full-page desktop before/after, comparison image, mobile and login captures saved in redesign/. Both desktop captures use a 1440x1080 viewport and a completed four-incident rehearsal.

## Observability extension — 2026-10-10

- Added real psutil telemetry with a dedicated sampler, signed ingestion, validation, 30-minute/900-per-node SQLite retention, and authenticated history API.
- Added node-selectable CPU/RAM charts, 1/5/15/30-minute windows, process CPU/RSS table, explicit fresh/stale/gap states and hover/keyboard sample inspection.
- Added topology based on registered nodes and incident endpoints, event-driven illustrative movement, labelled recorded-evidence replay, and source/destination timeline with nearest sample correlation. No fabricated graphs, packet captures, traffic rates or attack results.
- Styling remains Tailwind utilities + inline SVG, without a chart library or framework. State colors and IBM Plex typography remain intact.
- 43 Python tests pass. Existing full browser workflow passes. Observability workflow passes, including real peer evidence/replay, range/node selection, keyboard access, reduced motion, mobile fit and isolated stale/empty/gap fixtures.
- Screenshots: redesign/observability.png and redesign/observability-mobile.png.
- Cloud acceptance remains pending on the operator's actual provider accounts. Local runtime-host resources are shared; Colab host-visible measurements are not guaranteed container quotas.
